package com.example.android.coffeeapp;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.CheckBox;
import android.widget.RadioButton;
import android.widget.TextView;

import java.text.Format;
import java.text.NumberFormat;


public class MainActivity extends AppCompatActivity {
    private CheckBox chk1, chk2, chk3;
    private RadioButton rdb1, rdb2, rdb3;
    private Order anOrder;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    public void selectedType(View view) {

    }

    public void plusDrink(View view) {
        anOrder.addDrink();
        int number = anOrder.getNumberOfDrink();
    }

    /**
     * This method is called when the order button is clicked.
     */
    public void submitOrder(View view) {

        displayPrice(anOrder.orderPrice());
    }

    public void cancelOrder(View view) {
        chk1 = (CheckBox) findViewById(R.id.checkBox);
        chk2 = (CheckBox) findViewById(R.id.checkBox2);
        chk3 = (CheckBox) findViewById(R.id.checkBox3);
        rdb1 = (RadioButton) findViewById(R.id.radioButton4);
        rdb2 = (RadioButton) findViewById(R.id.radioButton5);
        rdb3 = (RadioButton) findViewById(R.id.radioButton6);
        while (anOrder.getNumberOfDrink() != 0) {
            anOrder.removeDrink();
            if (chk1.isChecked()) {
                chk1.toggle();
            }

            if (chk2.isChecked()) {
                chk2.toggle();
            }
            if (chk3.isChecked()) {
                chk3.toggle();
            }

            if (rdb1.isChecked()) {
                rdb1.toggle();
            }
            if (rdb2.isChecked()) {
                rdb2.toggle();
            }

            if (rdb3.isChecked()) {
                rdb3.toggle();
            }

        }
        displayPrice(anOrder.orderPrice());
    }
    /**
     * This method displays the given quantity value on the screen.
     */

    /**
     * This method displays the given price on the screen.
     */
    private void displayPrice(double number) {
        TextView priceTextView = (TextView) findViewById(R.id.text_view_result);
        priceTextView.setText(NumberFormat.getCurrencyInstance().format(number));
    }

    private void displayOrder() {
        TextView orderTextView = (TextView) findViewById(R.id.text_view_order);
        orderTextView.setText(anOrder.toString());
    }

    public void onRadioButtonClicked(View view) {
        // Is the button now checked?
        boolean checked = ((RadioButton) view).isChecked();

        switch (view.getId()) {
            case R.id.radioButton4:
                if (checked)
                    anOrder.setTypePrice(0.50);
                break;
            case R.id.radioButton5:
                if (checked)
                    anOrder.setTypePrice(1);
                break;
            case R.id.radioButton6:
                if (checked)
                    anOrder.setTypePrice(1.50);
                break;

        }
    }

    public void onCheckboxClicked(View view) {
        chk1 = (CheckBox) findViewById(R.id.checkBox);
        chk2 = (CheckBox) findViewById(R.id.checkBox2);
        chk3 = (CheckBox) findViewById(R.id.checkBox3);
        // Is the button now checked?
        boolean checked = ((CheckBox) view).isChecked();
        double OptionPrice = 0;
        if (chk1.isChecked()) {
            OptionPrice += 0.30;
        }
        if (chk2.isChecked()) {
            OptionPrice += 0.30;
        }
        if (chk3.isChecked()) {
            OptionPrice += 0.30;
        }
        anOrder.setOptionPrice(OptionPrice);
    }
}
