package com.example.android.coffeeapp;

public class Type extends Drink {

    private String name;
    private double price;

    public Type(String unType, String uneOptions, double unPrix, String unNom, double price){

        super(price, unType, uneOptions);
        this.name = unNom;
        this.price = unPrix;

    }
}
